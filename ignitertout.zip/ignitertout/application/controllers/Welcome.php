<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

    function __construct()
{

parent::__construct();

$this->load->library('acilang'); /// load the language lib or you can use autoload to load it in each class 


}
    
public function index()
{
 
    $this->acilang->set_lang("arabic"); //// Set Defualt site Language
    
    echo "the defualt languge in session is : ";
    echo  $this->acilang->get_lang(); /// get default lang that set
     
     echo "</br>"; /// new line
    
     echo $this->acilang->get_lang_str("home"); ////// get world translate
     
     echo "</br>"; /// new line
     echo "</br>"; /// new line
     echo "</br>"; /// new line
    
    
      $langs_avilb = $this->acilang->get_langs_data(); /// get avilable languges ;
     
      foreach ($langs_avilb as $lang) /// print avilble languges
        {
            echo $lang;
            echo "</br>"; /// new line
     echo "</br>"; /// new line
        }
   
     echo "</br>"; /// new line
     echo "the defualt languge style files named : ";
     echo  $this->acilang->get_style_setting(); /// get default lang style files folder name
   
 
 
}
}
